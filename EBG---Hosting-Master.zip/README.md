# EBG - Hosting Master
 Has the FAQ for EBG Hosting and the panel for users to get free coins
